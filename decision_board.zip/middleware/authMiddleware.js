const jwt = require("jsonwebtoken");
const config = require("config");
const { User } = require("../models");
module.exports = (req, res, next) => {
  const authHeader = req.get("Authorization");
  if (!authHeader) {
    const error = new Error("not Authorized");
    error.statusCode = 401;
    throw error;
  }

  let decodedToken;
  let token;
  try {
    token = authHeader.split(" ")[1];
    decodedToken = jwt.verify(token, config.get("JWT_key"));
  } catch (err) {
    const error = new Error("Please Login.");
    error.statusCode = 401;
    throw error;
  }
  if (!decodedToken) {
    const error = new Error("not Authorized");
    error.statusCode = 401;
    throw error;
  }
  if (!decodedToken.userId) {
    const error = new Error("not Authorized");
    error.statusCode = 401;
    throw error;
  }
  User.findOne({ where: { id: decodedToken.userId } })
    .then((user) => {
      if (!user) {
        const error = new Error("Please Login.");
        error.statusCode = 401;
        throw error;
      }
      req.userId = decodedToken.userId;
      next();
    })
    .catch((error) => {
      throw error;
    });
};
