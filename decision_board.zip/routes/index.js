module.exports = {
  dashboard: require("./dashboard"),
  auth: require("./auth"),
  sheet: require("./sheet"),
};
