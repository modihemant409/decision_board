const express = require("express");
const router = express.Router();
const auth = require("../middleware/authMiddleware");
const { DashboardController } = require("../controller");

router.post("/addLogo", auth, DashboardController.addLogo);
router.delete("/deleteLogo", auth, DashboardController.deleteLogo);
router.get("/getLogo", auth, DashboardController.getLogos);
router.post("/createDashboard", auth, DashboardController.createDashboard);
router.get("/getDashboard", auth, DashboardController.getDashboard);
router.post("/renameDashboard", auth, DashboardController.renameDashboard);
router.post("/shareDashboard", auth, DashboardController.shareDashboard);
router.get(
  "/openSharedDashboard/:dashboardId",
  DashboardController.openSharedDashboard
);
module.exports = router;
