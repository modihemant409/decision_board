const express = require("express");
const router = express.Router();
const auth = require("../middleware/authMiddleware");
const { SheetController } = require("../controller");

router.post("/addSheet", auth, SheetController.addSheet);
router.post("/addSheetData", auth, SheetController.addSheetData);
router.put("/updateSheetData", auth, SheetController.updateSheetData);
router.get("/getSheets/:dashboardId", auth, SheetController.getSheet);
router.post("/addSheetTab", auth, SheetController.addSheetTab);
router.post("/addTabInfo", auth, SheetController.addTabInfo);
router.get("/getAllTabs/:sheetId", auth, SheetController.getAllTabs);
router.get("/getCharts/:sheetTabId", auth, SheetController.getCharts);
router.post("/addChart", auth, SheetController.addChart);
router.put("/updateChart", auth, SheetController.updateChart);
router.post("/addComment", auth, SheetController.addComment);
module.exports = router;
