const express = require("express");
const app = express();

const dotenv = require("dotenv");
const cors = require("cors");
const path = require("path");

const db = require("./db/connection");
//models and routes
const models = require("./models");
const Routes = require("./routes");

app.use(express.json());
app.use("/assets", express.static(path.join(__dirname, "assets")));

app.use(cors());

app.use((req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "OPTIONS,GET,POST");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type,Accept");
  next();
});

app.use("/api/v1/auth", Routes.auth);
app.use("/api/v1/dashboard", Routes.dashboard);
app.use("/api/v1/sheet", Routes.sheet);

//error handling
app.use((error, req, res, next) => {
  console.log(error);
  const status = false;
  const statusCode = error.statusCode || 500;
  const message = error.message;
  const data = error.data;
  res.status(statusCode).json({ status: status, message: message, data: data });
});
db.sync()
  // db.sync({ alter: true })
  .then((result) => {
    Server = app.listen(process.env.Port, (e) => {
      console.log("server is listening on " + process.env.Port + " port");
    });
  })
  .catch((err) => {
    console.log(err);
  });
