const joi = require("joi");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const config = require("config");
const { User } = require("../models");
const { OAuth2Client } = require("google-auth-library");
const client = new OAuth2Client(process.env.GOOGLE_ID);
// exports.login = async (req, res, next) => {
//   const schema = joi.object({
//     type: joi.string().required().valid("login", "social_login"),
//     email: joi.string().email().lowercase().required(),
//   });

//   const schema_pass = joi.object({
//     password: joi.required(),
//   });

//   const schema_image = joi.object({
//     image: joi.required(),
//     name: joi.string().required(),
//   });

//   try {
//     await schema.validateAsync({ email: req.body.email, type: req.body.type });

//     const emailcheck = await User.findOne({
//       where: { email: req.body.email },
//     });

//     if (!emailcheck && req.body.type == "login") {
//       return res
//         .status(422)
//         .json({ status: false, message: "email not found" });
//     } else if (!emailcheck && req.body.type == "social_login") {
//       await schema_image.validateAsync({
//         image: req.body.image,
//         name: req.body.name,
//       });

//       const data = await User.create({
//         name: req.body.name,
//         email: req.body.email,
//         image: req.body.image,
//         password: null,
//         type: req.body.type,
//       });

//       const token = await jwt.sign(
//         { email: req.body.email, userId: data.id },
//         config.auth_key
//       );

//       data.token = token;
//       data.save();

//       return res.status(200).json({
//         data: data,
//         status: true,
//         message: "social login successfully",
//       });
//     } else if (req.body.type == "login") {
//       if (emailcheck.type == "social_login")
//         return res.status(401).json({
//           status: false,
//           message: "You were login with social login so please login with that",
//         });

//       await schema_pass.validateAsync({ password: req.body.password });

//       const passcheck = bcrypt.compareSync(
//         req.body.password,
//         emailcheck.password
//       );

//       if (!passcheck)
//         return res
//           .status(422)
//           .json({ data: [], status: false, message: "password not matched" });

//       const token = await jwt.sign(
//         { email: emailcheck.email, userId: emailcheck.id },
//         config.auth_key
//       );

//       emailcheck.token = token;
//       emailcheck.save();

//       res.status(200).json({
//         data: emailcheck,
//         status: true,
//         message: "login successfully",
//       });
//     } else if (req.body.type == "social_login") {
//       const token = await jwt.sign(
//         { email: req.body.email, userId: emailcheck.id },
//         config.auth_key
//       );

//       emailcheck.token = token;
//       emailcheck.save();

//       return res.status(200).json({
//         data: emailcheck,
//         status: true,
//         message: "social login successfully",
//       });
//     } else {
//       return res.status(402).json({
//         data: [],
//         status: false,
//         message: "Something went wrong",
//       });
//     }
//   } catch (err) {
//     err.status = 403;
//     next(err);
//   }
// };

// exports.register = async (req, res, next) => {
//   const schema = joi.object({
//     name: joi.string().required(),
//     email: joi.string().email().required(),
//     password: joi.string().required(),
//   });

//   try {
//     await schema.validateAsync(req.body);

//     const emailcheck = await User.findOne({
//       where: { email: req.body.email },
//     });

//     if (emailcheck)
//       return res.status(422).send({ status: false, message: "email exists" });

//     const data = await User.create({
//       name: req.body.name,
//       email: req.body.email,
//       password: await bcrypt.hash(req.body.password, 12),
//       type: "login",
//     });

//     res.status(200).json({
//       data: data,
//       status: true,
//       message: "register successfully",
//     });
//   } catch (err) {
//     err.status = 403;
//     next(err);
//   }
// };

// exports.logout = async (req, res, next) => {
//   try {
//     const data = await User.findOne({ where: { id: req.user_id } });
//     data.token = null;
//     data.save();

//     return res.status(200).json({
//       data: [],
//       status: true,
//       message: "user logout successfully",
//     });
//   } catch (err) {
//     err.status = 403;
//     next(err);
//   }
// };

exports.socialLogin = async (req, res, next) => {
  try {
    const schema = joi.object({
      token: joi.required(),
      device_token: joi.allow(),
      access_token: joi.allow(),
    });
    await schema.validateAsync(req.body);
    const { token, device_token, access_token } = req.body;
    const ticket = await client.verifyIdToken({
      idToken: token,
      audience: process.env.GOOGLE_ID,
    });
    const { name, email, picture } = ticket.getPayload();
    let user = await User.findOne({
      where: { email: email },
    });
    if (!user) {
      user = await User.create({
        name,
        email,
        profile_url: picture,
        access_token: access_token,
        device_token: device_token ? device_token : null,
      });
    }
    let token1;
    token1 = jwt.sign(
      { email: user.email, userId: user.id },
      config.get("JWT_key")
    );
    // console.log("token1", token1);
    user = await User.findOne({ where: { id: user.id } });
    user.token = token1;
    await user.save();
    await user.reload();
    delete user.dataValues.password;
    // console.log("user token", user.token);
    delete user.dataValues.memberCategoryId;
    delete user.dataValues.updatedAt;
    delete user.dataValues.createdAt;
    delete user.dataValues.is_blocked;
    delete user.dataValues.device_token;
    delete user.dataValues.device_type;
    delete user.dataValues.email_verified;

    res.status(201);
    return res.json({
      data: user,
      status: true,
      message: "logged in successfully",
    });
  } catch (error) {
    next(error);
  }
};
