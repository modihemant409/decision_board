module.exports = {
  DashboardController: require("./dashboardController"),
  AuthController: require("./AuthController"),
  SheetController: require("./SheetController"),
};
