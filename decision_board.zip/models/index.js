module.exports = {
  Dashboard: require("./Dashboard"),
  Logo: require("./Logo"),
  User: require("./User"),
  Sheet: require("./Sheet"),
  SheetData: require("./SheetData"),
  Chart: require("./Charts"),
  SheetTab: require("./SheetTabs"),
};
