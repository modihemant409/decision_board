const { Sequelize, DataTypes, Model } = require("sequelize");
const Logo = require("./Logo");
const connection = require("../db/connection");
const Sheet = require("./Sheet");

class SheetTab extends Model {}

SheetTab.init(
  {
    name: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    label: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    report_for: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
  },
  {
    // Other model options go here
    sequelize: connection, // We need to pass the connection instance
    modelName: "sheetTabs", // We need to choose the model name
    tableName: "sheetTabs",
  }
);

Sheet.hasOne(SheetTab);
SheetTab.belongsTo(Sheet);

Logo.hasMany(SheetTab, { as: "logo", foreignKey: "logoId" });
SheetTab.belongsTo(Logo, { foreignKey: "logoId" });

Logo.hasMany(SheetTab, { as: "banner", foreignKey: "bannerId" });
SheetTab.belongsTo(Logo, { foreignKey: "bannerId" });

module.exports = SheetTab;
